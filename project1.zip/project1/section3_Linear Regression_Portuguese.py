import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn import linear_model
import numpy.random
import time

# load data
def load_data(data_name):
    data = pd.read_csv(data_name,sep=";")
    print(data.head())
    print("data scale:", data.shape)
    features = list(data.columns)
    features_x = features[:30]+features[32:33]
    data_x = data.values[:, :30]
    data_y = data.values[:, 32:33]
    data_x = data_x[:30] + [data_x[32]]
    a = np.mat(data_y).ravel()
    b = a[0]
    c = set(b)
    print(a)
    print(b)
    print(c)
    data_y_ = np.zeros(())

    return data,features_x,data_x,data_y

def sigmoid(z):
    return 1 / (1 + np.exp(-z))
def model(x, theta):
    return sigmoid(np.dot(x,theta.T))
# 损失
def cost(x,y,theta):
    left = np.multiply(-y, np.log(model(x,theta)))
    right = np.multiply(1-y, np.log(1-model(x,theta)))
    return np.sum(left-right) / (len(x))
# 偏导
def gradient(x,y,theta):
    grad = np.zeros(theta.shape)
    error = (model(x,theta) - y).ravel()
    for j in range(len(theta.ravel())):
        term = np.multiply(error, x[:,j])
        grad[0,j] = np.sum(term) / len(x)
    return grad

STOP_ITER = 0
STOP_COST = 1
STOP_GRAD = 2
def stop_croteropm(type, value, threshold):
#     设定三种不同的停止策略
    if type == STOP_ITER:
        return value > threshold
    elif type == STOP_COST:
        return abs(value[-1]-value[-2]) < threshold
    elif type == STOP_GRAD:
        return np.linalg.norm(value) < threshold
# 洗牌
def shuffle_data(data):
    return np.random.shuffle(data)





data,features,data_x,data_y = load_data("student-por.csv")
theta = np.zeros([1,30])
# print(data_x[:5])
# print(data_y[:5])
# print(theta)
print(data_x.shape, data_y.shape, theta.shape)
# print(cost(data_x,data_y,theta))